# Water Tank Controller — RTL to GDSII

## Project
Digital water tank controller implemented in RTL and taken through
the OpenLane physical-design flow using the SKY130A platform.

## Contents
- Source files and configuration files, where available
- Physical-design results
- Available reports and logs
- Graphs and screenshots folders for analysis artifacts

## Review before submission
- Confirm the final RTL and configuration are included.
- Review timing, area, utilization, DRC and LVS reports.
- Add floorplan, placement and routed-layout screenshots to screenshots/.
- Add generated graphs to graphs/.
- Report only metrics verified in the actual run reports.
